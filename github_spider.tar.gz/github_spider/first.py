import os

os.remove("haha.txt")

os.remove("dummy1.json")

os.remove("dummy2.json")